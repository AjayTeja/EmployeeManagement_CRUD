import React, { useState, useEffect } from "react";
import axios from "axios";

import {
  Button,
  Card,
  CardBody,
  CardFooter,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
} from "reactstrap";

const EditEmployee = (props) => {
  const [employee, setEmployee] = useState({
    employeeId: "",
    firstname: "",
    lastname: "",
    email: "",
  });
  const Url = "http://localhost:8080/api/employee/" + props.match.params.id;

  useEffect(() => {
    const GetData = async () => {
      const result = await axios.get(Url);
      setEmployee(result.data);
    };
    GetData();
  }, []);
  const updateEmployee = async (e) => {
    e.preventDefault();
    const data = {
      employeeId: employee.employeeId,
      firstname: employee.firstname,
      lastname: employee.lastname,
      email: employee.email,
    };
    console.log(JSON.stringify(data));
    console.log("check 1");
    await axios
      .put("http://localhost:8080/api/employee/" + employee.employeeId, data)
      .then((result) => {
        props.history.push("/EmployeeList");
      });
  };
  const onChange = (e) => {
    e.persist();
    setEmployee({ ...employee, [e.target.name]: e.target.value });
    console.log(JSON.stringify(employee));
  };
  return (
    <div className="app flex-row align-items-center">
      <Container>
        <Row className="justify-content-center">
          <Col md="12" lg="10" xl="8">
            <Card className="mx-4">
              <CardBody className="p-4">
                <Form onSubmit={updateEmployee}>
                  <h1>Register</h1>
                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      name="employeeId"
                      id="employeeId"
                      placeholder="employeeId"
                      value={employee.employeeId}
                      onChange={onChange}
                    />
                  </InputGroup>

                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      name="firstname"
                      id="firstname"
                      placeholder="firstname"
                      value={employee.firstname}
                      onChange={onChange}
                    />
                  </InputGroup>

                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      placeholder="lastname"
                      name="lastname"
                      id="lastname"
                      value={employee.lastname}
                      onChange={onChange}
                    />
                  </InputGroup>

                  <InputGroup className="mb-4">
                    <Input
                      type="text"
                      placeholder="email"
                      name="email"
                      id="email"
                      value={employee.email}
                      onChange={onChange}
                    />
                  </InputGroup>

                  <CardFooter className="p-4">
                    <Row>
                      <Col xs="12" sm="6">
                        <Button
                          type="submit"
                          className="btn btn-info mb-1"
                          block
                        >
                          <span>Save</span>
                        </Button>
                      </Col>

                      <Col xs="12" sm="6">
                        <Button className="btn btn-info mb-1" block>
                          <span>Cancel</span>
                        </Button>
                      </Col>
                    </Row>
                  </CardFooter>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

EditEmployee.propTypes = {};

export default EditEmployee;

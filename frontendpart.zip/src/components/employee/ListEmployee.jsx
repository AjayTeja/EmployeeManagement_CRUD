import React from "react";

import axios from "axios";

import { useState, useEffect } from "react";

import {
  Badge,
  Card,
  CardBody,
  CardHeader,
  Col,
  Pagination,
  PaginationItem,
  PaginationLink,
  Row,
  Table,
} from "reactstrap";

const ListEmployee = (props) => {
  const [data, setData] = useState([]);
  useEffect(() => {
    const GetData = async () => {
      const result = await axios("http://localhost:8080/api/employee/all");
      console.log(result.data);
      setData(result.data);
    };

    GetData();
  }, []);
  const deleteeployee = (id) => {
    axios
      .delete("http://localhost:8080/api/employee/delete/" + id)

      .then((result) => {
        props.history.push("/");
      });
  };

  const editemployee = (id) => {
    props.history.push({
      pathname: "/edit/" + id,
    });
  };
  return (
    <div className="animated fadeIn">
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <i className="fa fa-align-justify"></i> Employee List
            </CardHeader>

            <CardBody>
              <Table hover bordered striped responsive size="sm">
                <thead>
                  <tr>
                    <th>Employee Id</th>

                    <th>FirstName</th>

                    <th>LastName</th>

                    <th>Email</th>
                  </tr>
                </thead>

                <tbody>
                  {data.map((item, idx) => {
                    return (
                      <tr>
                        <td>{item.employeeId}</td>

                        <td>{item.firstname}</td>

                        <td>{item.lastname}</td>

                        <td>{item.email}</td>

                        <td>
                          <div class="btn-group">
                            <button
                              className="btn btn-primary"
                              onClick={() => {
                                editemployee(item.employeeId);
                              }}
                            >
                              Edit
                            </button>

                            <button
                              className="btn btn-danger"
                              onClick={() => {
                                deleteeployee(item.employeeId);
                              }}
                            >
                              Delete
                            </button>
                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                deleteeployee(item.employeeId);
                              }}
                            >
                              View
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

ListEmployee.propTypes = {};

export default ListEmployee;
